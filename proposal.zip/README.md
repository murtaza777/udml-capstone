#Capstone Proposal

This is  the final submission of the Udacity's Machine Learning Engineering Capstone Project Proposal.

The proposal has been outlined in the `proposal.pdf` document.

The number of rows in the training data have been pulled by the `MurtazaEq.ipynb` notebook.

The input files discussed in the proposal document can be obtained from https://www.kaggle.com/c/LANL-Earthquake-Prediction/data